INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Camilo Ernesto","Rodriguez Moreno","crodrigr@gmail.com","3154887",250000);
INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Maria Celina","Torres Serrano","ctorres@gmail.com","3154887",150000);
INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Juan Carlos","Camargo Perez","jcamargo@gmail.com","3154887",50000);
INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Diego Fernando","Rangel Pinto","drangel@gmail.com","3154887",450000);
INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Pedro Andres","Moreno Oyola","pmoreno@gmail.com","3154887",750000);
INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Juan Carlos","Martinez Puyana","jmartinez@gmail.com","3154887",20000);
INSERT INTO clientes (nombres,apellidos,email,telefono,saldo) VALUES("Diana Milena","Tarazona Suarez","dtarazona@gmail.com","3154887",250000);

