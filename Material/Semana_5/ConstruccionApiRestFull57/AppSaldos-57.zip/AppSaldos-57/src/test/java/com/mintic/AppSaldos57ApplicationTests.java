package com.mintic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppSaldos57ApplicationTests {

	@Test
	void contextLoads() {
	}

}
